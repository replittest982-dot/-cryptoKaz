# Основные настройки

token = "6671494612:AAGtWws-znaddSaxJOSvNsVquz6udAwHwb4" # Токен бота (@botfather)
bot_username = "@Elite_Casinobot" # @ бота
admins = [640612893] # ID админов (через запятую)

# =======================================

# Настройки канала

channel_invite = "https://t.me/EliteCasinoBets" # Ссылка на канал
channel_id = -1002196027912 # ID канала (@getmyid_bot)

# =======================================

# Настройки юзер бота

api_id = "9139417"
api_hash = "d32b6fbbf46b371a8f38925867403394"

# Найти можно тут >>> https://my.telegram.org/apps

# =======================================

# Игры

mines_map = {'mines:A1': '🎁','mines:A2': '🎁','mines:A3': '🎁','mines:A4': '🎁','mines:A5': '🎁', 
            'mines:B1': '🎁','mines:B2': '🎁','mines:B3': '🎁','mines:B4': '🎁','mines:B5': '🎁', 
            'mines:C1': '🎁','mines:C2': '🎁','mines:C3': '🎁','mines:C4': '🎁','mines:C5': '🎁', 
            'mines:D1': '🎁','mines:D2': '🎁','mines:D3': '🎁','mines:D4': '🎁','mines:D5': '🎁', 
            'mines:E1': '🎁','mines:E2': '🎁','mines:E3': '🎁','mines:E4': '🎁','mines:E5': '🎁'}
##Кофицент
mine_cof = { 
  3: 0.15,
  4: 0.2,
  5: 0.26,
  6: 0.33,
  7: 0.41,
  8: 0.5,
  9: 0.63,
  10: 0.8,
  11: 1,
  12: 1.18,
  13: 1.33,
  14: 1.5,
  15: 1.65,
  16: 1.8,
  17: 2.15,
  18: 2.5,
  19: 2.8,
  20: 3.5,
  21: 4.3,
  22: 5.5,
  23: 8,
  24: 16
      }

# =======================================

# Картинки

menu = "https://i.imgur.com/h7xu9qb.png" # Картинка меню
win = "https://i.imgur.com/AqoGPmW.png" # Картинка победы
lose = "https://i.imgur.com/AWgJtU2.png" # Картинка проигрыша
odd = "https://i.imgur.com/eAIc1wJ.jpeg" # Картинка чет
non_odd = "https://i.imgur.com/VBeBStb.jpeg" # Картинка нечет
more = "https://i.imgur.com/WZHNNl7.jpeg" # Картинка больше
less = "https://i.imgur.com/14P3ePK.jpeg" # Картинка меньше
mines = "https://i.imgur.com/wQ9EKkO.jpeg" # Картинка мины
promah = "https://i.imgur.com/eVqeyZk.jpeg" # Картинка промах (баскет)
popal = "https://i.imgur.com/NSa0B0G.jpeg" # Картинка попадание (баскет)
cube1 = "https://i.imgur.com/s0kawLL.jpeg" # Картинка победа 1 (кубик)
cube2 = "https://i.imgur.com/H55YJXg.jpeg" # Картинка победа 2 (кубик)
draw = "https://i.imgur.com/x0M0UEq.jpeg" # Картинка ничья (кубик)
sector1 = "https://i.imgur.com/tnnPqtZ.jpeg" # Картинка сектор 1
sector2 = "https://i.imgur.com/qpsLSGz.jpeg" # Картинка сектор 2
sector3 = "https://i.imgur.com/wXNeFCz.jpeg" # Картинка сектор 3